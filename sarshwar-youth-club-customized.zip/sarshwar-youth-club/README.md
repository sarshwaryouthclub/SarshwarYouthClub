# Sarshwar Youth Club website

A responsive bilingual (English/Nepali) static website for Sarshwar Youth Club, Sarshwar, Siraha, Nepal.

## Club details already configured
- Email: sarshwaryouth@gmail.com
- Phone: 9807855449
- Address: सिरहा न.पा. १२, सारस्वर, सिरहा, नेपाल
- Facebook: https://www.facebook.com/sarasvara.yuva.klaba/about

## Included features
- Attractive dashboard preview (`dashboard.html`) with sample activity cards, event planning, sample charts and quick actions
- Responsive desktop/mobile navigation
- English ↔ Nepali language switch
- About, programs, events, gallery and members/volunteers sections
- Donation information area prepared for the official QR image
- Contact form that opens the visitor's email app with the message addressed to the club
- Clickable email, telephone and Facebook links
- Free static hosting compatible with GitHub Pages, Netlify or Cloudflare Pages

## Important: add the real donation QR
The actual QR image was not attached with the customization details, so this package does not include or invent one. Before accepting donations:
1. Copy the club's original QR image into `assets/` and name it `donation-qr.png`.
2. In `index.html`, find the `<div class="qr-placeholder">...</div>` block in the donation section. Replace it with:

```html
<div class="qr-placeholder">
  <img src="assets/donation-qr.png" alt="Official Sarshwar Youth Club donation QR" style="width:180px;max-width:100%;height:auto">
  <strong>Official donation QR</strong>
  <small>Scan to support the club</small>
</div>
```

3. Test scanning the published QR with a phone and verify the recipient name/account before sharing the site. Do not alter, stretch, or regenerate the QR.

## Update photos and team details
- Add approved club photos to `assets/` and replace the sample gallery tiles in `index.html` with `<img>` elements.
- Replace generic member role cards with approved names, roles and photos. Do not publish personal details without consent.
- Update event dates, venue and times only after they are confirmed. The displayed blood donation event is explicitly marked as needing confirmation.

## Publish free with GitHub Pages
1. Extract `sarshwar-youth-club.zip` on your computer.
2. Sign in or create an account at https://github.com/.
3. Create a public repository named `sarshwar-youth-club`.
4. Upload the contents of this folder to the repository root: `index.html`, `dashboard.html`, `styles.css`, `script.js`, `README.md`, and the `assets` folder. Upload the files themselves, not an extra nested project folder.
5. Open repository **Settings → Pages**.
6. Under **Build and deployment**, choose **Deploy from a branch**, select `main` and `/ (root)`, then save.
7. Wait for the deployment to finish. GitHub will show the website URL in Settings → Pages.
8. Open the live site and test the language switch, mobile navigation, email/phone/Facebook links, contact form and QR.

## Dashboard and form limitations
`dashboard.html` is a visual admin dashboard preview. Its figures and event activities are sample content, not live records. The static website does not have a secure admin login or database, does not save event/member records, and does not process or verify donations. The contact form opens the visitor's email app; it does not store messages on the website. A secure backend or external form service is needed for real admin editing, member registrations, saved donation records or payment processing.


## Donation QR code

The supplied Khalti QR image is included at `assets/donation-qr.jpg` and shown on both the public homepage donation section and the dashboard donation panel. Keep the image file in this exact relative path when uploading the site. Before publishing, scan-test the QR and verify the displayed recipient name and payment destination. The website does not process or verify payments.
