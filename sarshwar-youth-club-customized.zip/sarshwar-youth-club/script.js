// Configure this address before publishing. The contact form uses the visitor's email app.
const CLUB_EMAIL = 'sarshwaryouth@gmail.com';
let currentLanguage = 'en';
const langToggle = document.getElementById('langToggle');
function setLanguage(language) {
  currentLanguage = language;
  document.body.classList.toggle('nepali', language === 'ne');
  document.documentElement.lang = language === 'ne' ? 'ne' : 'en';
  document.querySelectorAll('[data-en][data-ne]').forEach(el => {
    const value = el.dataset[language];
    if (value !== undefined) el.innerHTML = value;
  });
  langToggle.textContent = language === 'en' ? 'नेपाली' : 'English';
  langToggle.setAttribute('aria-label', language === 'en' ? 'Switch to Nepali' : 'Switch to English');
}
langToggle.addEventListener('click', () => setLanguage(currentLanguage === 'en' ? 'ne' : 'en'));
const menuToggle = document.getElementById('menuToggle');
const nav = document.getElementById('mainNav');
menuToggle.addEventListener('click', () => nav.classList.toggle('open'));
nav.querySelectorAll('a').forEach(link => link.addEventListener('click', () => nav.classList.remove('open')));
document.getElementById('year').textContent = new Date().getFullYear();
document.getElementById('contactForm').addEventListener('submit', event => {
  event.preventDefault();
  const data = new FormData(event.currentTarget);
  const name = String(data.get('name') || '').trim();
  const reply = String(data.get('reply') || '').trim();
  const topic = String(data.get('topic') || 'Other');
  const message = String(data.get('message') || '').trim();
  const subject = encodeURIComponent(`[Sarshwar Youth Club] ${topic} enquiry from ${name}`);
  const body = encodeURIComponent(`Name: ${name}\nReply contact: ${reply}\nTopic: ${topic}\n\n${message}`);
  window.location.href = `mailto:${CLUB_EMAIL}?subject=${subject}&body=${body}`;
});
